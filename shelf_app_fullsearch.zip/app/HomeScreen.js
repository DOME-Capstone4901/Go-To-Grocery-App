import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, TextInput, FlatList } from 'react-native';
import { logoutUser, getUser } from '../utils/storage';

const SAMPLE_ITEMS = [
  { id: '1', name: 'Apples', category: 'Fruit' },
  { id: '2', name: 'Bananas', category: 'Fruit' },
  { id: '3', name: 'Broccoli', category: 'Vegetable' },
  { id: '4', name: 'Chicken Breast', category: 'Protein' },
  { id: '5', name: 'Milk', category: 'Dairy' },
  { id: '6', name: 'Eggs', category: 'Dairy' },
  { id: '7', name: 'Bread', category: 'Bakery' },
];

export default function HomeScreen({ navigation }) {
  const [userEmail, setUserEmail] = useState('');
  const [query, setQuery] = useState('');

  useEffect(() => {
    async function loadUser() {
      const user = await getUser();
      if (user && user.email) {
        setUserEmail(user.email);
      }
    }
    loadUser();
  }, []);

  async function handleLogout() {
    await logoutUser();
    navigation.replace('Login');
  }

  const filteredItems = SAMPLE_ITEMS.filter(item =>
    item.name.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Hi{userEmail ? `, ${userEmail}` : ''} 👋</Text>
      <Text style={styles.subtitle}>Search your grocery ideas:</Text>

      <TextInput
        placeholder="Search items (e.g., milk, apples)"
        style={styles.searchInput}
        value={query}
        onChangeText={setQuery}
      />

      <FlatList
        data={filteredItems}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.itemCard}>
            <Text style={styles.itemName}>{item.name}</Text>
            <Text style={styles.itemCategory}>{item.category}</Text>
          </View>
        )}
        ListEmptyComponent={
          <Text style={styles.emptyText}>No items match your search yet.</Text>
        }
        style={{ marginTop: 10 }}
      />

      <TouchableOpacity style={styles.button} onPress={handleLogout}>
        <Text style={styles.btnText}>Log Out</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFBFAE',
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  title: {
    fontSize: 28,
    color: '#1E1E1E',
    fontWeight: 'bold',
  },
  subtitle: {
    fontSize: 16,
    marginTop: 6,
    color: '#333',
  },
  searchInput: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 10,
    marginTop: 20,
    fontSize: 16,
  },
  itemCard: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 12,
    marginVertical: 6,
    borderLeftWidth: 4,
    borderLeftColor: '#3AAFA9',
  },
  itemName: {
    fontSize: 16,
    fontWeight: '600',
  },
  itemCategory: {
    fontSize: 13,
    color: '#555',
    marginTop: 2,
  },
  emptyText: {
    marginTop: 20,
    textAlign: 'center',
    color: '#444',
  },
  button: {
    backgroundColor: '#3AAFA9',
    padding: 15,
    borderRadius: 12,
    marginTop: 15,
  },
  btnText: {
    color: '#fff',
    textAlign: 'center',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
