
"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
export default function SignupPage() {
  const [form, setForm] = useState({ email: "", password: "", name: "" });
  const [msg, setMsg] = useState<string | null>(null);
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    setLoading(true);
    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form)
    });
    const data = await res.json();
    setLoading(false);
    if (!res.ok) setMsg(data.error ?? "Failed");
    else {
      setMsg("Registered! Redirecting...");
      setTimeout(() => router.push("/"), 600);
    }
  }
  const minLenOk = form.password.length >= 8;
  return (
    <main className="mx-auto max-w-md">
      <div className="card">
        <h1 className="mb-6 text-2xl font-semibold">Create your account</h1>
        <form onSubmit={submit} className="space-y-3">
          <input className="input" placeholder="Name" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
          <input className="input" type="email" placeholder="Email" required value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
          <div className="relative">
            <input className="input pr-24" type={show ? "text" : "password"} placeholder="Password (min 8)" required value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} />
            <button type="button" className="absolute inset-y-0 right-2 my-1 rounded-lg px-3 text-sm text-gray-600 hover:bg-gray-100" onClick={() => setShow(s => !s)} aria-label="Toggle password visibility">
              {show ? "Hide" : "Show"}
            </button>
          </div>
          <p className={`text-xs ${minLenOk ? "text-green-600" : "text-gray-500"}`}>Password must be at least 8 characters.</p>
          <button disabled={loading} className="btn" type="submit">{loading ? "Creating..." : "Create account"}</button>
        </form>
        {msg && <p className="mt-3 text-sm text-gray-700">{msg}</p>}
        <p className="mt-6 text-sm text-gray-600">Already have an account? <a className="text-indigo-600 hover:underline" href="/login">Log in</a></p>
      </div>
    </main>
  );
}
