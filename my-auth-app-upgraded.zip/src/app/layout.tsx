
import "./globals.css";
export const metadata = {
  title: "My Auth App",
  description: "Minimal Next.js auth starter with Tailwind",
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 antialiased">
        <div className="mx-auto max-w-6xl px-4 py-10">
          <header className="mb-10 flex items-center justify-between">
            <a href="/" className="text-xl font-semibold">MyAuth</a>
            <nav className="text-sm text-gray-600">
              <a className="hover:text-gray-900" href="/signup">Sign up</a>
              <span className="mx-2">·</span>
              <a className="hover:text-gray-900" href="/login">Log in</a>
            </nav>
          </header>
          {children}
        </div>
      </body>
    </html>
  );
}
