
"use client";
import { useEffect, useState } from "react";
export default function Home() {
  const [state, setState] = useState<any>(null);
  useEffect(() => { fetch("/api/auth/me").then(r => r.json()).then(setState); }, []);
  return (
    <main className="mx-auto max-w-2xl">
      <div className="card">
        <h1 className="mb-4 text-2xl font-semibold">Home</h1>
        <p className="mb-4 text-sm text-gray-600">Quick check of session and a logout button.</p>
        <pre className="mb-4 rounded-xl bg-gray-50 p-3 text-sm">{JSON.stringify(state, null, 2)}</pre>
        <form onSubmit={async (e) => { e.preventDefault(); await fetch("/api/auth/logout", { method: "POST" }); location.reload(); }}>
          <button className="btn" type="submit">Logout</button>
        </form>
      </div>
    </main>
  );
}
