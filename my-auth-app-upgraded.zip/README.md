
# My Auth App — Upgraded (Next.js + Prisma + Tailwind)

- Next.js App Router + API routes
- Prisma + SQLite
- bcrypt password hashing
- JWT in HttpOnly cookies
- Zod validation
- Tailwind CSS styling + improved UX (loading state, errors, redirects)

## Quickstart
```bash
npm install
cp .env.example .env   # or: copy .env.example .env (Windows)
# edit .env -> set JWT_SECRET
npx prisma generate
npx prisma migrate dev --name init
npm run dev
```
