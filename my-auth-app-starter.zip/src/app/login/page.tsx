"use client";
import { useState } from "react";

export default function LoginPage() {
  const [form, setForm] = useState({ email: "", password: "" });
  const [msg, setMsg] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form)
    });
    const data = await res.json();
    if (!res.ok) setMsg(data.error ?? "Failed");
    else setMsg("Logged in!");
  }

  return (
    <main style={{ maxWidth: 420, margin: "3rem auto" }}>
      <h1>Log in</h1>
      <form onSubmit={submit} style={{ display: "grid", gap: "0.5rem" }}>
        <input
          type="email"
          placeholder="Email"
          required
          value={form.email}
          onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
        />
        <input
          type="password"
          placeholder="Password"
          required
          value={form.password}
          onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
        />
        <button type="submit">Log in</button>
      </form>
      {msg && <p>{msg}</p>}
      <p style={{ marginTop: "1rem" }}><a href="/signup">Need an account? Sign up</a></p>
    </main>
  );
}
