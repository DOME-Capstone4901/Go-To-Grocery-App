"use client";
import { useEffect, useState } from "react";

export default function Home() {
  const [state, setState] = useState<any>(null);

  useEffect(() => {
    fetch("/api/auth/me").then(r => r.json()).then(setState);
  }, []);

  return (
    <main style={{ maxWidth: 620, margin: "3rem auto" }}>
      <h1>Home</h1>
      <p>Quick check of session and a logout button.</p>
      <pre>{JSON.stringify(state, null, 2)}</pre>
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          await fetch("/api/auth/logout", { method: "POST" });
          location.reload();
        }}
      >
        <button type="submit">Logout</button>
      </form>
      <p><a href="/signup">Sign up</a> | <a href="/login">Log in</a></p>
    </main>
  );
}
