"use client";
import { useState } from "react";

export default function SignupPage() {
  const [form, setForm] = useState({ email: "", password: "", name: "" });
  const [msg, setMsg] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form)
    });
    const data = await res.json();
    if (!res.ok) setMsg(data.error ?? "Failed");
    else setMsg("Registered & logged in!");
  }

  return (
    <main style={{ maxWidth: 420, margin: "3rem auto" }}>
      <h1>Sign up</h1>
      <form onSubmit={submit} style={{ display: "grid", gap: "0.5rem" }}>
        <input
          placeholder="Name"
          value={form.name}
          onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
        />
        <input
          type="email"
          placeholder="Email"
          required
          value={form.email}
          onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
        />
        <input
          type="password"
          placeholder="Password (min 8)"
          required
          value={form.password}
          onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
        />
        <button type="submit">Create account</button>
      </form>
      {msg && <p>{msg}</p>}
      <p style={{ marginTop: "1rem" }}><a href="/login">Already have an account? Log in</a></p>
    </main>
  );
}
