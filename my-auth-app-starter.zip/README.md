# My Auth App (Next.js + Prisma)

A minimal email/password auth starter using **Next.js App Router**, **Prisma + SQLite**, **bcrypt**, **JWT in HttpOnly cookies**, and **Zod**.

## Quickstart

```bash
# 1) Install deps
npm install

# 2) Create your env file
cp .env.example .env
# Then open .env and set a long random JWT_SECRET

# 3) Init DB
npx prisma generate
npx prisma migrate dev --name init

# 4) Run
npm run dev
```

Open:
- http://localhost:3000/signup
- http://localhost:3000/login

## Tech

- Next.js API Route Handlers (App Router)
- Prisma ORM (SQLite by default)
- bcrypt for hashing
- JWT in HttpOnly cookies
- Zod validation

Swap SQLite for Postgres by changing `DATABASE_URL` in `.env` and your Prisma datasource.
